# deps
tlmgr install apa6
tlmgr install etoolbox
tlmgr install hanging
tlmgr install mdframed
tlmgr install minted
tlmgr install apacite
tlmgr install natbib
tlmgr install titlesec
tlmgr install setspace
tlmgr install caption
