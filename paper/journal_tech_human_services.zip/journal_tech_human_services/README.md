if needed, install dependencies with `tlmgr`
```
source deps.sh
```

build the pdf file with
```
source build.sh
```
